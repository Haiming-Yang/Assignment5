package iss.java.mail;

import javax.mail.*;
import java.io.IOException;
import java.util.Properties;

public class MailReceiver2014302580179 {
    /**
     * 接收邮件的props文件
     */
    private final transient Properties props = System.getProperties();
    /**
     * 邮件服务器登录验证
     */
    private transient MailAuthenticator2014302580179 authenticator;

    /**
     * 邮箱session
     */
    private Session session;

    /**
     * 初始化邮件发送器
     *
     * @param imapHostName
     *                IMAP邮件服务器地址
     * @param username
     *                发送邮件的用户名(地址)
     * @param password
     *                发送邮件的密码
     */
    public MailReceiver2014302580179(final String imapHostName, final String username,
                                     final String password) {
        // 初始化props
        props.put("mail.store.protocol", "imap");
        props.put("mail.imap.host", imapHostName);
        // 验证
        authenticator = new MailAuthenticator2014302580179(username, password);
        // 创建session
        session = Session.getInstance(props, authenticator);
    }

    /**
     * 检测是否有新邮件
     * @return 布尔值, 返回是否有新邮件到达
     * @throws MessagingException 查询邮件异常
     */
    public boolean listen() throws MessagingException {
        boolean receiveOrNot = false;
        try {
            Store store = session.getStore();
            store.connect();
            Folder folder = store.getFolder("INBOX");
            folder.open(Folder.READ_ONLY);
            
            
            if (folder.getNewMessageCount()>0) {
				receiveOrNot = true;
			}


        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        }
        return receiveOrNot;
    }

    /**
     * 获取自动回复
     * @param sender 自动回复邮件的发件人邮箱地址
     * @param subject 自动回复邮件的主题
     * @return 自动回复邮件内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {

        String reply = "未收到自动回复";
        try {
            Store store = session.getStore();
            store.connect();
            Folder folder = store.getFolder("INBOX");
            folder.open(Folder.READ_ONLY);
            //获取收件箱邮件总数
            int num = folder.getMessageCount();
            
            boolean containOrNot = false;
          
            //获取最新邮件
            Message m_reply = folder.getMessage(num);
            //获取最新邮件主题
            String m_subject = m_reply.getSubject();
          
            
            //检测主题是否含“自动回复”
            if (m_subject.contains("自动回复")) {
				containOrNot = true;
			}
       
           //满足以上，判定为需要的自动回复，给reply赋值
            if (containOrNot) {
				reply = (String) m_reply.getContent();
			}

        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        }

        return reply;
    }
}

