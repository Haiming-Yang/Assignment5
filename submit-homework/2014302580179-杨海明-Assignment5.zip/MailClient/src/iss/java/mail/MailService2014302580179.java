package iss.java.mail;

import java.io.IOException;

import javax.mail.MessagingException;

public class MailService2014302580179 implements IMailService {
	 /**
     * 邮件发送器
     */
    private MailSender2014302580179 sender;
    /**
     *  邮件接收器
     */
    private MailReceiver2014302580179 receiver;

    /**
     * 用户名
     */
    private static final String username = "mailtest179@163.com";
    /**
     * 密码
     */
    private static final String password = "fmjfspluczzufeer";

    /**
     * 发送邮件
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException 发送邮件错误
     */

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		sender.send(recipient, subject, content);
		
	}
	/**
     * 接收自动回复内容
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */
	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		return receiver.getReplyMessageContent(sender, subject);
	}
	 /**
     * 初始化并连接所有的邮件服务器
     * @throws MessagingException 初始化或连接异常
     */
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		 sender = new MailSender2014302580179("smtp.163.com", username,password);
	     receiver = new MailReceiver2014302580179("imap.163.com", username, password);
	}
	/**
     * 查询新邮件
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException 询问服务器出错
     */
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		return receiver.listen();	
	}
}
